# ==============================================================================
# DASHBOARD DE DISTRIBUCIÓN Y ABASTECIMIENTO DE JUEGOS (2019 - 2026) EN R SHINY
# ==============================================================================

# 1. Instalación y Carga Automática de Librerías
needed_packages <- c("shiny", "bslib", "dplyr", "plotly", "DT")
new_packages <- needed_packages[!(needed_packages %in% installed.packages()[,"Package"])]
if(length(new_packages)) install.packages(new_packages)

library(shiny)
library(bslib)
library(dplyr)
library(plotly)
library(DT)

# 2. Generación del Dataset Sintético Histórico (2019 - 2026)
set.seed(42)

years <- 2019:2026
months_order <- c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
proveedores <- c("EveryMatrix", "Betfounders", "Elantil", "Calimaco", "IGP", "SoftGamings", "RubyPlay", "SkillOnNet", "Yggdrasil", "Pragmatic Play")
plataformas <- c("Casino LatAm", "BetGlobal", "PlayEuro", "Vegas Online", "WinMaster")
estados <- c("Abastecido", "En Tránsito", "Crítico")

data_list <- list()

for (y in years) {
  growth <- 1.0 + (y - 2019) * 0.22
  for (m in months_order) {
    n_records <- sample(4:7, 1)
    for (i in 1:n_records) {
      prov <- sample(proveedores, 1)
      plat <- sample(plataformas, 1)
      units <- as.integer(sample(1200:4800, 1) * growth)
      estado <- sample(estados, 1, prob = c(0.70, 0.20, 0.10))
      juego <- paste0(substr(prov, 1, 4), "_Slot_", sample(100:999, 1))
      
      data_list[[length(data_list) + 1]] <- data.frame(
        Year = y,
        Mes = factor(m, levels = months_order),
        Proveedor = prov,
        Juego = juego,
        Plataforma_Destino = plat,
        Unidades_Enviadas = units,
        Estado_Stock = estado,
        stringsAsFactors = FALSE
      )
    }
  }
}

df <- do.call(rbind, data_list)

# 3. Interfaz de Usuario (UI)
theme_dark_custom <- bs_theme(
  bg = "#0b1f3a",
  fg = "#ffffff",
  primary = "#00fff5",
  base_font = font_google("Inter")
)

ui <- fluidPage(
  theme = theme_dark_custom,
  tags$head(
    tags$style(HTML("
      body { background-color: #0b1f3a; color: white; padding: 15px; }
      .card-custom {
        background-color: #0f3460;
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 15px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.3);
      }
      .header-box {
        background-color: #16213e;
        padding: 15px 25px;
        border-radius: 8px;
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .kpi-title { font-size: 13px; color: #a2a8d3; text-align: center; margin: 0; }
      .kpi-value { font-size: 36px; color: #00fff5; font-weight: bold; text-align: center; margin-top: 5px; }
      .selectize-input { background-color: #ffffff !important; color: #000000 !important; }
      label { color: #a2a8d3; font-size: 11px; font-weight: bold; }
      table.dataTable tbody tr { background-color: #0f3460 !important; color: white !important; }
      table.dataTable header { background-color: #16213e !important; color: #00fff5 !important; }
    "))
  ),
  
  # Cabecera con Filtros
  div(class = "header-box",
      div(
        h2("DISTRIBUCIÓN Y ABASTECIMIENTO DE JUEGOS (2019 - 2026)", style = "color: #00fff5; margin: 0; font-size: 20px; font-weight: bold;"),
        p("Análisis histórico y evolutivo mensual / anual de distribución", style = "color: #a2a8d3; margin: 0; font-size: 12px;")
      ),
      div(style = "display: flex; gap: 12px;",
          div(style = "width: 150px;",
              selectInput("filter_prov", "Proveedor", choices = c("Todos", sort(unique(df$Proveedor))), selected = "Todos")
          ),
          div(style = "width: 140px;",
              selectInput("filter_year", "Año", choices = c("Todos los Años", years), selected = "Todos los Años")
          ),
          div(style = "width: 140px;",
              selectInput("filter_month", "Mes", choices = c("Todos los Meses", months_order), selected = "Todos los Meses")
          )
      )
  ),
  
  # Gráfico Superior
  div(class = "card-custom",
      h4("Evolución Temporal del Abastecimiento", style = "color: #00fff5; font-size: 14px; margin-top: 0;"),
      plotlyOutput("trend_plot", height = "220px")
  ),
  
  # Fila Inferior
  fluidRow(
    column(4,
           div(class = "card-custom",
               p("Total Unidades Distribuidas", class = "kpi-title"),
               div(textOutput("kpi_units"), class = "kpi-value")
           ),
           div(class = "card-custom",
               h4("Volumen por Proveedor", style = "font-size: 14px; margin-top: 0;"),
               plotlyOutput("bar_plot", height = "290px")
           )
    ),
    
    column(4,
           div(class = "card-custom",
               h4("Distribución por Plataformas de Destino", style = "font-size: 14px; margin-top: 0; text-align: center;"),
               plotlyOutput("network_plot", height = "390px")
           )
    ),
    
    column(4,
           div(class = "card-custom",
               h4("Detalle de Registros", style = "font-size: 14px; margin-top: 0;"),
               DTOutput("data_table")
           )
    )
  )
)

# 4. Lógica del Servidor (Server)
server <- function(input, output, session) {
  
  df_prov <- reactive({
    data <- df
    if (input$filter_prov != "Todos") {
      data <- data %>% filter(Proveedor == input$filter_prov)
    }
    data
  })
  
  df_filtered <- reactive({
    data <- df_prov()
    if (input$filter_year != "Todos los Años") {
      data <- data %>% filter(Year == as.numeric(input$filter_year))
    }
    if (input$filter_month != "Todos los Meses") {
      data <- data %>% filter(Mes == input$filter_month)
    }
    data
  })
  
  output$trend_plot <- renderPlotly({
    data_p <- df_prov()
    
    if (input$filter_year == "Todos los Años") {
      trend_df <- data_p %>% 
        group_by(Year) %>% 
        summarise(Unidades_Enviadas = sum(Unidades_Enviadas), .groups = "drop")
      
      p <- plot_ly(trend_df, x = ~Year, y = ~Unidades_Enviadas, type = 'scatter', mode = 'lines+markers+text',
                   fill = 'tozeroy', fillcolor = 'rgba(0, 255, 245, 0.15)',
                   line = list(color = '#00fff5'), marker = list(color = '#00fff5'),
                   text = ~format(Unidades_Enviadas, big.mark = ","), textposition = 'top center')
    } else {
      sel_yr <- as.numeric(input$filter_year)
      trend_df <- data_p %>% 
        filter(Year == sel_yr) %>% 
        group_by(Mes) %>% 
        summarise(Unidades_Enviadas = sum(Unidades_Enviadas), .groups = "drop")
      
      p <- plot_ly(trend_df, x = ~Mes, y = ~Unidades_Enviadas, type = 'scatter', mode = 'lines+markers+text',
                   line = list(color = '#00fff5'), marker = list(color = '#00fff5'),
                   text = ~format(Unidades_Enviadas, big.mark = ","), textposition = 'top center')
    }
    
    p %>% layout(
      paper_bgcolor = 'rgba(0,0,0,0)', plot_bgcolor = 'rgba(0,0,0,0)',
      font = list(color = 'white', size = 10),
      xaxis = list(showgrid = TRUE, gridcolor = '#16213e', title = ""),
      yaxis = list(showgrid = TRUE, gridcolor = '#16213e', title = "Unidades"),
      margin = list(l = 30, r = 20, t = 10, b = 20)
    )
  })
  
  output$kpi_units <- renderText({
    data <- df_filtered()
    format(sum(data$Unidades_Enviadas), big.mark = ",")
  })
  
  output$bar_plot <- renderPlotly({
    data <- df_filtered()
    prov_summary <- data %>% 
      group_by(Proveedor) %>% 
      summarise(Unidades_Enviadas = sum(Unidades_Enviadas), .groups = "drop") %>% 
      arrange(Unidades_Enviadas)
    
    plot_ly(prov_summary, x = ~Unidades_Enviadas, y = ~reorder(Proveedor, Unidades_Enviadas), 
            type = 'bar', orientation = 'h',
            marker = list(color = '#00fff5'),
            text = ~format(Unidades_Enviadas, big.mark = ","), textposition = 'outside') %>% 
      layout(
        paper_bgcolor = 'rgba(0,0,0,0)', plot_bgcolor = 'rgba(0,0,0,0)',
        font = list(color = 'white', size = 10),
        xaxis = list(showgrid = FALSE, visible = FALSE),
        yaxis = list(showgrid = FALSE, title = ""),
        margin = list(l = 80, r = 50, t = 10, b = 10)
      )
  })
  
  output$network_plot <- renderPlotly({
    data <- df_filtered()
    colors <- c('Abastecido' = '#00ff88', 'En Tránsito' = '#ffcc00', 'Crítico' = '#ff4d4d')
    
    plot_ly(data, x = ~Plataforma_Destino, y = ~Proveedor, size = ~Unidades_Enviadas, 
            color = ~Estado_Stock, colors = colors, type = 'scatter', mode = 'markers',
            hoverinfo = 'text', text = ~paste0("Juego: ", Juego, "<br>Unidades: ", Unidades_Enviadas),
            sizes = c(10, 28)) %>% 
      layout(
        paper_bgcolor = 'rgba(0,0,0,0)', plot_bgcolor = 'rgba(0,0,0,0)',
        font = list(color = 'white', size = 10),
        xaxis = list(showgrid = TRUE, gridcolor = '#16213e', title = "Plataforma"),
        yaxis = list(showgrid = TRUE, gridcolor = '#16213e', title = ""),
        legend = list(orientation = "h", x = 0, y = 1.12),
        margin = list(l = 80, r = 10, t = 10, b = 30)
      )
  })
  
  output$data_table <- renderDT({
    data <- df_filtered() %>% select(Year, Mes, Proveedor, Unidades_Enviadas, Estado_Stock)
    datatable(tail(data, 15), options = list(pageLength = 6, dom = 't', ordering = FALSE), rownames = FALSE) %>% 
      formatStyle('Estado_Stock', color = styleEqual(c('Crítico', 'En Tránsito', 'Abastecido'), c('#ff4d4d', '#ffcc00', '#00ff88')), fontWeight = 'bold')
  })
}

# 5. Ejecutar la Aplicación
shinyApp(ui = ui, server = server)